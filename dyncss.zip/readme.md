Add new themes in folder: src/theme/css/
Theme names must be name-theme.css for example: avon-theme.css or blue-theme.css
default.css is empty, then only Ionic default styles will show up if no theme is loaded.
